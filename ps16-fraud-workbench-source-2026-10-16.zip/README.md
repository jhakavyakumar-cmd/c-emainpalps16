# PS16 Fraud Investigation Workbench

A local, synthetic-data-only analyst workbench for investigating UPI fraud-ring signals. It is deliberately dependency-free: Node.js is the only runtime requirement.

## Run

Open PowerShell in this folder and run:

```powershell
node server.js
```

Then open `http://localhost:4173` in a browser. The supplied dataset path is configured by default. To use another compatible data folder, set `PS16_DATA_DIR` before launching.

```powershell
$env:PS16_DATA_DIR = 'C:\path\to\data'
node server.js
```

## Validate

```powershell
node --test server.test.js
```

## Data boundaries

- The operational API reads only `observable/` data and, if present, the separately analyst-maintained `confirmed_accounts.csv` for D1.
- `ground_truth/` is accessed solely by the Evaluation endpoint.
- Analyst statuses and notes are stored locally in `analyst-state.json`, created only after an analyst action.

## Key screens

- Overview, Accounts, Alerts, Account Investigation, Network Explorer, Operational Rings, Evaluation, and Scoring Rules.
- Selecting a signal highlights linked transaction evidence in the account graph.
- Operational rings are inferred from high-priority accounts and observable transaction/shared-infrastructure links; they never use ground-truth ring membership.
