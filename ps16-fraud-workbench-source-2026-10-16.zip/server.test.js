const test = require('node:test');
const assert = require('node:assert/strict');
const { buildModel, risk, CAPS, RULES } = require('./server');

test('authoritative caps and thresholds are stable', () => {
  assert.deepEqual(CAPS, { 'Velocity / Flow':35, Topology:45, Device:45, IP:25, Complaints:45, Behavior:30, Merchant:5 });
  assert.equal(Object.values(CAPS).reduce((a,b)=>a+b,0),230);
  assert.equal(risk(0),'Clean'); assert.equal(risk(19),'Clean'); assert.equal(risk(20),'Low Risk');
  assert.equal(risk(49),'Low Risk'); assert.equal(risk(50),'Moderate Risk'); assert.equal(risk(89),'Moderate Risk'); assert.equal(risk(90),'High Risk');
  assert.equal(new Set(RULES.map(r=>r.id)).size,18);
});

test('operational model loads supplied observable data without ground-truth fields', () => {
  const model = buildModel();
  assert.equal(model.accounts.length,5000);
  assert.equal(model.tx.length,154099);
  assert.ok(model.summaries.every(a => !Object.hasOwn(a,'ground_truth_status') && !Object.hasOwn(a,'ring_id')));
  assert.ok(model.summaries.every(a => a.score >= 0 && a.score <= 230));
  assert.ok(model.summaries.every(a => a.risk === risk(a.score)));
});

test('complete account population is classified and overview counts conserve totals', () => {
  const model = buildModel();
  const levels = ['Clean', 'Low Risk', 'Moderate Risk', 'High Risk'];
  const counts = Object.fromEntries(levels.map(level => [level, model.summaries.filter(a => a.risk === level).length]));
  assert.equal(model.summaries.length, model.accounts.length);
  assert.ok(model.summaries.some(a => a.score === 0 && a.signals.length === 0));
  assert.ok(counts.Clean > 0);
  assert.equal(Object.values(counts).reduce((sum, n) => sum + n, 0), model.accounts.length);
  assert.ok(model.summaries.every(a => a.score >= 0 && a.score <= 230));
});
